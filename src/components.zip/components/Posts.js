import React from 'react'

 const Posts = ({posts, loading}) => {
if(loading){
    return <h2>Loading</h2> 
}
  return (
   <>
   {posts.map((contact) => (
          
                <tr>
                  <td>{contact.name}</td>
                  <td>{contact.email}</td>
                  <td>{contact.role}</td>
                  <td></td> 
                </tr>
         
            ))}
   </>
  )
}
export default Posts